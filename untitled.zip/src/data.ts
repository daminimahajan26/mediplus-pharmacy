import { Activity, Pill, ShieldCheck, Stethoscope, Syringe, Truck } from 'lucide-react';

export const siteData = {
  name: "Mediplus Pharmacy",
  phone: "+91 98765 43210",
  email: "info@medipluspharmacy.com",
  address: "123 Health Street, Pune, Maharashtra 411001",
  mission: "To make healthcare accessible, affordable, and reliable for every family.",
  hours: [
    { days: "Monday – Saturday", time: "8:00 AM – 10:00 PM" },
    { days: "Sunday", time: "9:00 AM – 6:00 PM" }
  ],
  services: [
    { title: "Prescription Refills", icon: Pill, description: "Quick and accurate prescription fulfilling with our automated tracking system." },
    { title: "Home Delivery", icon: Truck, description: "Medicines delivered straight to your doorstep securely and on time." },
    { title: "Health Checkups", icon: Stethoscope, description: "Basic health diagnostics and professional checkups right at the pharmacy." },
    { title: "Blood Pressure Monitoring", icon: Activity, description: "Regular BP monitoring services to keep your vital logs in check." },
    { title: "Diabetes Care Products", icon: Syringe, description: "Comprehensive range of diabetes care products and guidance." },
    { title: "OTC Medicines", icon: ShieldCheck, description: "A wide approved variety of over-the-counter medications for everyday needs." }
  ],
  products: [
    { name: "Paracetamol 500mg", category: "Pain Relief", price: "₹30" },
    { name: "Vitamin C Tablets", category: "Supplements", price: "₹199" },
    { name: "Digital Thermometer", category: "Medical Device", price: "₹299" },
    { name: "Hand Sanitizer 500ml", category: "Hygiene", price: "₹99" },
    { name: "Cough Syrup", category: "Cold & Flu", price: "₹120" }
  ],
  pharmacist: {
    name: "Dr. Ananya Sharma, PharmD",
    experience: "8+ years of experience",
    specialty: "Specialized in patient counseling and medication management"
  },
  testimonials: [
    { quote: "Quick delivery and excellent service! Always reliably stocked.", name: "Rahul P." },
    { quote: "Friendly staff and genuine medicines. I trust them completely.", name: "Priya M." },
    { quote: "Best pharmacy in the area. Very knowledgeable pharmacist.", name: "Amit K." }
  ]
};
