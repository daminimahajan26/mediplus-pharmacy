import { siteData } from '../data';
import { Mail, MapPin, Phone, Clock } from 'lucide-react';

export default function Contact() {
  return (
    <footer id="contact" className="bg-gray-900 border-t border-gray-800 pt-20 pb-10 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          <div className="lg:col-span-1">
            <span className="font-display font-bold text-3xl text-white tracking-tight mb-6 flex items-center gap-2">
              Mediplus<span className="text-blue-500">.</span>
            </span>
            <p className="text-gray-400 mb-6 leading-relaxed">
              {siteData.mission}
            </p>
            <div className="flex gap-4">
              {/* Optional Social Icons could go here */}
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg tracking-wide">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex gap-3">
                <Phone className="w-5 h-5 text-blue-500 shrink-0" />
                <span className="text-gray-300">{siteData.phone}</span>
              </li>
              <li className="flex gap-3">
                <Mail className="w-5 h-5 text-blue-500 shrink-0" />
                <span className="text-gray-300">{siteData.email}</span>
              </li>
              <li className="flex gap-3">
                <MapPin className="w-5 h-5 text-blue-500 shrink-0" />
                <span className="text-gray-300">{siteData.address}</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg tracking-wide">Opening Hours</h4>
            <ul className="space-y-4">
              {siteData.hours.map((schedule, idx) => (
                <li key={idx} className="flex gap-3">
                  <Clock className="w-5 h-5 text-teal-500 shrink-0" />
                  <div>
                    <span className="block text-white font-medium">{schedule.days}</span>
                    <span className="text-gray-400 text-sm">{schedule.time}</span>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg tracking-wide">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#home" className="hover:text-blue-400 transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-blue-400 transition-colors">About Us</a></li>
              <li><a href="#services" className="hover:text-blue-400 transition-colors">Our Services</a></li>
              <li><a href="#products" className="hover:text-blue-400 transition-colors">Products</a></li>
            </ul>
          </div>

        </div>

        <div className="pt-8 border-t border-gray-800 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} {siteData.name}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
