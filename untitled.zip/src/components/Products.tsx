import { siteData } from '../data';
import { motion } from 'motion/react';
import { Tag } from 'lucide-react';

export default function Products() {
  return (
    <section id="products" className="py-24 bg-white border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div className="max-w-2xl">
            <h2 className="text-sm font-bold tracking-widest text-blue-600 uppercase mb-3">Featured Products</h2>
            <h3 className="font-display text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Explore Our Healthcare Catalog
            </h3>
            <p className="text-lg text-gray-600">
              A curated selection of our most requested over-the-counter medicines, supplements, and medical devices. Visit us in-store to view our complete inventory.
            </p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {siteData.products.map((product, idx) => (
            <motion.div
              key={product.name}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: idx * 0.1 }}
              className="group border border-gray-100 bg-white rounded-2xl overflow-hidden hover:shadow-xl hover:border-blue-100 transition-all"
            >
              <div className="h-40 bg-gray-50 flex items-center justify-center p-6 relative overflow-hidden group-hover:bg-blue-50/50 transition-colors">
                {/* Simulated product placeholder image */}
                <div className="w-20 h-20 bg-white rounded-full shadow-sm flex items-center justify-center relative z-10">
                  <Tag className="w-8 h-8 text-blue-300" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-gray-100/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <div className="p-5">
                <span className="text-xs font-bold uppercase tracking-wider text-teal-600 mb-2 block">
                  {product.category}
                </span>
                <h4 className="font-bold text-gray-900 mb-2 line-clamp-2">{product.name}</h4>
                <div className="flex items-center justify-between mt-4">
                  <span className="text-lg font-black text-blue-900">{product.price}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
