import { siteData } from '../data';
import { CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function About() {
  const highlights = [
    "Expert Pharmacist on Duty",
    "100% Genuine Medicines",
    "Affordable Pricing",
    "Neighborhood Focused"
  ];

  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="grid grid-cols-2 gap-4"
          >
            <img 
              src="https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&q=80&w=600" 
              alt="Pharmacy Inside" 
              className="rounded-2xl shadow-lg w-full h-64 object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1550831107-1553da8c8464?auto=format&fit=crop&q=80&w=600" 
              alt="Medical Supplies" 
              className="rounded-2xl shadow-lg w-full h-64 object-cover translate-y-8"
            />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-sm font-bold tracking-widest text-blue-600 uppercase mb-3">About Us</h2>
            <h3 className="font-display text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              A Legacy of Care and Trust in Pune
            </h3>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              {siteData.name} is a trusted neighborhood pharmacy dedicated to providing quality medicines, healthcare products, and professional guidance. We focus on customer care, affordability, and timely service.
            </p>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Our mission is to establish a strong bond of trust with our community by strictly dispensing authentic medicines, maintaining safe storage protocols, and ensuring every patient receives the care and guidance they deserve.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {highlights.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-teal-500" />
                  <span className="font-medium text-gray-800">{item}</span>
                </div>
              ))}
            </div>
            
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-6 flex items-start gap-4">
              <img 
                src="https://images.unsplash.com/photo-1594824436951-7f12bcbe4efd?auto=format&fit=crop&q=80&w=200" 
                alt="Dr. Ananya Sharma" 
                className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-sm"
              />
              <div>
                <h4 className="font-bold text-gray-900">{siteData.pharmacist.name}</h4>
                <p className="text-sm text-blue-700 font-medium mb-1">{siteData.pharmacist.experience}</p>
                <p className="text-sm text-gray-600">{siteData.pharmacist.specialty}</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
