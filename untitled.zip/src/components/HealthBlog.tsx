import { motion } from 'motion/react';
import { ArrowRight, BookOpen } from 'lucide-react';

export default function HealthBlog() {
  const blogs = [
    {
      title: "Understanding Your Blood Pressure",
      excerpt: "Learn how to read and maintain a healthy blood pressure for a long life.",
      category: "Heart Health",
      date: "Oct 12, 2026",
      image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=400"
    },
    {
      title: "Essential Vitamins for Immune System",
      excerpt: "Discover the top supplements and foods that boost your immunity safely.",
      category: "Nutrition",
      date: "Oct 05, 2026",
      image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=400"
    },
    {
      title: "Managing Seasonal Allergies",
      excerpt: "OTC medicines and natural remedies to get through allergy season.",
      category: "Wellness",
      date: "Sep 28, 2026",
      image: "https://images.unsplash.com/photo-1512069772995-ec65e75ebe08?auto=format&fit=crop&q=80&w=400"
    }
  ];

  return (
    <section id="blog" className="py-24 bg-gray-50 border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div className="max-w-2xl">
            <h2 className="text-sm font-bold tracking-widest text-blue-600 uppercase mb-3">Health Blog</h2>
            <h3 className="font-display text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Latest Insights & Tips
            </h3>
            <p className="text-lg text-gray-600">
              Read our latest articles authored by our pharmacists to stay informed about health, wellness, and medical advice.
            </p>
          </div>
          <a href="#" className="hidden md:inline-flex items-center gap-2 text-blue-600 font-bold hover:text-blue-800 transition-colors">
            View All Articles <ArrowRight className="w-5 h-5" />
          </a>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {blogs.map((post, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-gray-100 flex flex-col group"
            >
              <div className="relative h-48 overflow-hidden bg-gray-200">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 bg-teal-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-sm">
                  {post.category}
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex justify-between items-center text-sm text-gray-500 font-medium mb-3">
                  <div className="flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4" />
                    5 min read
                  </div>
                  <span>{post.date}</span>
                </div>
                <h4 className="font-bold text-xl text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                  {post.title}
                </h4>
                <p className="text-gray-600 mb-4 line-clamp-2">
                  {post.excerpt}
                </p>
                <div className="mt-auto">
                  <span className="inline-flex items-center font-bold text-blue-600 group-hover:text-blue-800 transition-colors cursor-pointer text-sm gap-1">
                    Read More <ArrowRight className="w-4 h-4 translate-x-0 group-hover:translate-x-1 transition-transform" />
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
