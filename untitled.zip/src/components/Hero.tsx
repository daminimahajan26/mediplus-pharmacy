import { ArrowRight, ShieldCheck } from 'lucide-react';
import { siteData } from '../data';
import { motion } from 'motion/react';

export default function Hero() {
  return (
    <section id="home" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-blue-900 border-b border-blue-800">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/2 -right-1/4 w-[1000px] h-[1000px] rounded-full bg-blue-800/50 blur-3xl opacity-50 pointer-events-none" />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-left"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-800/50 border border-blue-700 text-blue-100 text-sm font-medium mb-6">
              <ShieldCheck className="w-4 h-4 text-blue-300" />
              Trusted Neighborhood Pharmacy
            </div>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-7xl font-bold tracking-tight text-white mb-6 leading-tight">
              Quality Healthcare <br className="hidden sm:block"/>
              <span className="text-blue-400">For Every Family.</span>
            </h1>
            <p className="text-lg sm:text-xl text-blue-100 max-w-2xl mb-8 leading-relaxed font-light">
              {siteData.mission} We are dedicated to providing quality medicines, healthcare products, and professional guidance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="#products" 
                className="inline-flex items-center justify-center gap-2 bg-white text-blue-900 px-8 py-3.5 rounded-full font-semibold hover:bg-blue-50 transition-colors"
              >
                View Products
                <ArrowRight className="w-5 h-5" />
              </a>
              <a 
                href="#services" 
                className="inline-flex items-center justify-center gap-2 bg-blue-800 text-white px-8 py-3.5 rounded-full font-semibold hover:bg-blue-700 border border-blue-700 transition-colors"
              >
                Our Services
              </a>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-600/30 to-teal-400/20 rounded-3xl transform rotate-3 scale-105" />
            <img 
              src="https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&q=80&w=800" 
              alt="Pharmacy Professional" 
              className="relative rounded-3xl shadow-2xl object-cover h-[500px] w-full"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
